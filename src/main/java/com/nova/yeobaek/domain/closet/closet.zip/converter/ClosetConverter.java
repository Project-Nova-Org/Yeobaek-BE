package com.nova.yeobaek.domain.closet.converter;

import com.nova.yeobaek.domain.closet.domain.Closet;
import com.nova.yeobaek.domain.closet.dto.ClosetRequestDTO;
import com.nova.yeobaek.domain.closet.dto.ClosetResponseDTO;
import com.nova.yeobaek.domain.user.domain.User;
import org.springframework.stereotype.Component;

public class ClosetConverter {

    public Closet toEntity(User user, ClosetRequestDTO.Create request) {
        return Closet.create(user, request.name(), request.imageUrl());
    }

    public ClosetResponseDTO.Create toCreateResponse(Closet closet) {
        return new ClosetResponseDTO.Create(closet.getId());
    }
}
