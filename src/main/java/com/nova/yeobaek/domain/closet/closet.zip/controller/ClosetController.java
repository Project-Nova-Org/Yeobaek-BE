package com.nova.yeobaek.domain.closet.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nova.yeobaek.domain.closet.controller.docs.ClosetControllerDocs;
import com.nova.yeobaek.domain.closet.dto.ClosetRequestDTO;
import com.nova.yeobaek.domain.closet.dto.ClosetResponseDTO;
import com.nova.yeobaek.domain.closet.service.ClosetService;
import com.nova.yeobaek.global.auth.UserPrincipal;
import com.nova.yeobaek.global.payload.common.ApiResponse;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequiredArgsConstructor
@RequestMapping("/api/closets")
public class ClosetController implements ClosetControllerDocs {

	private final ClosetService closetService;

	@Override
	@PostMapping
	public ApiResponse<ClosetResponseDTO.Create> createCloset(
			@AuthenticationPrincipal UserPrincipal principal,
			@Valid @RequestBody ClosetRequestDTO.Create request
	) {
		Long closetId = closetService.create(principal.getUser(), request);
		return ApiResponse.success(new ClosetResponseDTO.Create(closetId));
	}
}
