package com.nova.yeobaek.domain.closet.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.nova.yeobaek.domain.closet.converter.ClosetConverter;
import com.nova.yeobaek.domain.closet.domain.Closet;
import com.nova.yeobaek.domain.closet.dto.ClosetRequestDTO;
import com.nova.yeobaek.domain.closet.repository.ClosetRepository;
import com.nova.yeobaek.domain.user.domain.User;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
@Transactional
public class ClosetService {
    private final ClosetRepository closetRepository;
    private final ClosetConverter closetConverter;

    public Long create(User user, ClosetRequestDTO.Create request) {
        Closet closet = closetConverter.toEntity(user, request);
        return closetRepository.save(closet).getId();
    }
}
