package com.nova.yeobaek.domain.closet.status;

import org.springframework.http.HttpStatus;

import com.nova.yeobaek.global.payload.status.ErrorReason;
import org.springframework.http.HttpStatus;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum ClosetErrorStatus implements ErrorReason {
	INVALID_CLOSET_NAME(
			HttpStatus.BAD_REQUEST,
			"CLOSET_400_1",
			"옷장 이름이 유효하지 않습니다"
	);



	private final HttpStatus httpStatus;
	private final String code;
	private final String message;
}
